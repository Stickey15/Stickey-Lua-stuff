
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName		= "Breakable Rock"
ENT.Category    = "Ore Nodes"
ENT.Author			= "Stickey"
ENT.Spawnable       = true


