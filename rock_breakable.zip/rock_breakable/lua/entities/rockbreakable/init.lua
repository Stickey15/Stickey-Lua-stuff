AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "hooks.lua" )


include( "shared.lua" )
include( "hooks.lua" )

function ENT:Initialize()
	self:SetModel("models/rust/env_node_stone_1.mdl") -- THE PROP THAT IS THE MENU IS SPAWNED ON!
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
end

hook.Add( "EntityTakeDamage", "EntityDamageThingy", function( target, dmginfo )
	if target:IsPlayer() then
		function ix.item.Spawn(uniqueID, entity:GetPos() )
		end
	end
end
