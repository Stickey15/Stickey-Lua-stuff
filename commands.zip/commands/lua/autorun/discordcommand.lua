hook.Add("OnPlayerChat", "DiscordCommand", function(ply, strText)
  if (ply != LocalPlayer()) then return end
  strText = string.lower(strText)
  
  if (strText == "!discord") then
    gui.OpenURL("https://google.com")
    return true
  end
end)